import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Nave {

	public static final int NORMAL = 1;

	// DATOS
	private int xInic, yInic;
	private int x, y;
	private int ancho, alto;
	private Image[] imgI;
	private Image[] imgD;
	private Image[] imgParada;
	private int estado;// correr, subir, bajar, parado
	private int velocidad;// + o -
	private int imgActual;
	// objetos que se mueven solos: var direccion,
	// var dirH y dirV
	private AreaDibujo areaDibujo;

	// CONSTRUCTOR
	public Nave(AreaDibujo areaDibujo) {
		this.areaDibujo = areaDibujo;
		ancho = 70;
		alto = 60;
		x = 400;// areaDibujo.getWidth()/2-ancho/2;
		xInic = x;
		y = 500;// areaDibujo.getHeight()-alto-15;
		yInic = y;
		estado = NORMAL;
		velocidad = 0;
		imgActual = 0;
		cargarImagenes();
	}

	
	// M�TODOS
	private void cargarImagenes() {
	
		imgI = new Image[2];
		imgD = new Image[2];
		imgParada = new Image[1];

		for (int i = 0; i < 2; i++) {
			imgI[i] = new ImageIcon(getClass().getResource("shipI" + (i + 1) + ".png")).getImage();

			imgD[i] = new ImageIcon(getClass().getResource("shipD" + (i + 1) + ".png")).getImage();
		}
		
		imgParada[0] = new ImageIcon(getClass().getResource("shipC.png")).getImage();
	}

	public void dibujar(Graphics g) {
		if (velocidad < 0) {
			g.drawImage(imgI[imgActual], x, y, ancho, alto, null);
		
		} else if (velocidad > 0) {
			g.drawImage(imgD[imgActual], x, y, ancho, alto, null);
		
		} else {
			g.drawImage(imgParada[0], x, y, ancho, alto, null);
		}
	}

	public void mover() {
		// controlar que no se salga o que aparezca
		// por otro lado
		if (x > 0 && velocidad < 0) {
			x = x + velocidad;
			if (x < 0) {
				x = 1;
			}
		}
		
		if (x > areaDibujo.getWidth() - ancho && velocidad > 0) {
			x = x + velocidad;
			if (x > areaDibujo.getWidth() - ancho) {
				x = areaDibujo.getWidth() - ancho;
			}
		}
		// cambiar la imagen CADA X MOVIMIENTOS
		if (velocidad != 0) {//
			imgActual++;
			if (imgActual == 1) {
				imgActual = 0;
			}
		} 
		
	}
	
	// GETTERS Y SETTERS
		public int getxInic() {
			return xInic;
		}

		public void setxInic(int xInic) {
			this.xInic = xInic;
		}

		public int getyInic() {
			return yInic;
		}

		public void setyInic(int yInic) {
			this.yInic = yInic;
		}

		public int getX() {
			return x;
		}

		public void setX(int x) {
			this.x = x;
		}

		public int getY() {
			return y;
		}

		public void setY(int y) {
			this.y = y;
		}

		public int getAncho() {
			return ancho;
		}

		public void setAncho(int ancho) {
			this.ancho = ancho;
		}

		public int getAlto() {
			return alto;
		}

		public void setAlto(int alto) {
			this.alto = alto;
		}

		public Image[] getImgI() {
			return imgI;
		}

		public void setImgI(Image[] imgI) {
			this.imgI = imgI;
		}

		public Image[] getImgD() {
			return imgD;
		}

		public void setImgD(Image[] imgD) {
			this.imgD = imgD;
		}

		public Image[] getImgParada() {
			return imgParada;
		}

		public void setImgParada(Image[] imgParada) {
			this.imgParada = imgParada;
		}

		public int getEstado() {
			return estado;
		}

		public void setEstado(int estado) {
			this.estado = estado;
		}

		public int getVelocidad() {
			return velocidad;
		}

		public void setVelocidad(int velocidad) {
			this.velocidad = velocidad;
		}

		public int getImgActual() {
			return imgActual;
		}

		public void setImgActual(int imgActual) {
			this.imgActual = imgActual;
		}

		public AreaDibujo getAreaDibujo() {
			return areaDibujo;
		}

		public void setAreaDibujo(AreaDibujo areaDibujo) {
			this.areaDibujo = areaDibujo;
		}


}
