import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Bala {

	private AreaDibujo areaDibujo;
	// tama�o y posicion de la bala
	private int x, y;
	private int ancho, alto;
	private Image b;

	private int velocidad;

	public Bala(AreaDibujo areaDibujo) {
		this.areaDibujo = areaDibujo;
		x = 0;
		y = 0;
		ancho = 12;
		alto = 22;
		velocidad = 2;
		cargarImg();
	}

	private void cargarImg() {
		b = new ImageIcon(getClass().getResource("shot.gif")).getImage();

	}

	public void dibujar(Graphics g) {

		g.drawImage(b, x, y, ancho, alto, null);

	}

	public void mover() {
		y = y + velocidad;
	}

	public AreaDibujo getAreaDibujo() {
		return areaDibujo;
	}

	public void setAreaDibujo(AreaDibujo areaDibujo) {
		this.areaDibujo = areaDibujo;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public int getAlto() {
		return alto;
	}

	public void setAlto(int alto) {
		this.alto = alto;
	}
}
