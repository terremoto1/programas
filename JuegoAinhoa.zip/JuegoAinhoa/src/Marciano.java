import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Marciano {

	private AreaDibujo areaDibujo;
	// tama�o y posicion de los marcianos
	private int x, y;
	private int ancho, alto;
	private int velocidad;
	private Image m;

	public Marciano(AreaDibujo areaDibujo) {
		this.areaDibujo = areaDibujo;
		x = 5;
		y = 50;
		ancho = 60;
		alto = 50;
		velocidad = 5;

		cargarImg();
	}

	public void cargarImg() {

		m = new ImageIcon(getClass().getResource("alien.png")).getImage();

	}

	public void dibujar(Graphics g) {

		g.drawImage(m, x, y, ancho, alto, null);
	}

	public void mover() {
		// controlar que no se salga o que aparezca
		// por otro lado
		if (x > 0 && velocidad < 0) {
			x = x + velocidad;
			
			if (x <0) {
				x = 1;
				
			}
		}

		if (x < areaDibujo.getWidth() - ancho && velocidad > 0) {
			x = x + velocidad;
			
			if (x > areaDibujo.getWidth() - ancho) {
				
				x = areaDibujo.getWidth() - ancho;
				
			}
		}
		
		if (x > areaDibujo.getWidth() - ancho && velocidad > 0) {
			
			
			if (x < areaDibujo.getWidth() - ancho) {
				
				//x = areaDibujo.getWidth() - ancho;
				y = +10;
			}
		}

	}

	////////////////////////////////////////

	public AreaDibujo getAreaDibujo() {
		return areaDibujo;
	}

	public void setAreaDibujo(AreaDibujo areaDibujo) {
		this.areaDibujo = areaDibujo;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public int getAlto() {
		return alto;
	}

	public void setAlto(int alto) {
		this.alto = alto;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}

	public Image getM() {
		return m;
	}

	public void setM(Image m) {
		this.m = m;
	}
}
