import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.Timer;

public class AreaDibujo extends Canvas {

	public static final int FILAS = 4;
	public static final int COLUMNAS = 7;

	private Graphics pantVirtual;
	private Image buffer;
	private Image fondo;
	private Nave nave;

	private Marciano marciano;
	private ArrayList<Marciano> marcianosArray;

	private Bala bala;
	private ArrayList<Bala> balasArray;

	private Timer reloj;

	private int[] estadoTeclas;
	public int sep = 20;

	public AreaDibujo() {
		// CREAR INSTANCIAS Y CARGAR FONDO
		nave = new Nave(this);

		balasArray = new ArrayList<Bala>();
		marcianosArray = new ArrayList<Marciano>();

		fondo = new ImageIcon(getClass().getResource("fondo.jpg")).getImage();

		registrarEventos();

		estadoTeclas = new int[3];// LEFT, RIGHT, SPACE
		estadoTeclas[0] = 0;// left
		estadoTeclas[1] = 0;// right
		estadoTeclas[2] = 0;// space(disparo)
		reloj.start();
		requestFocus();

		///////////////// MARCIANOS ////////////////

		for (int j = 0; j < FILAS; j++) {

			for (int i = 0; i < COLUMNAS; i++) {
				marciano = new Marciano(this);

				marciano.setX(marciano.getAncho() * (i % COLUMNAS) + sep * (i % COLUMNAS));

				marciano.setY(marciano.getY() * (j % FILAS) + sep * (j % FILAS));
				marcianosArray.add(marciano);
			}

		}

		///////////////// BALAS ////////////////
		for (int i = 0; i < 5; i++) {
			bala = new Bala(this);

			bala.setX(nave.getX() + 28);
			bala.setY(nave.getY() - 3);

			balasArray.add(bala);
		}
	}

	private void registrarEventos() {
		reloj = new Timer(40, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (nave.getEstado() == Nave.NORMAL) {
					nave.mover();
					for (int i = 0; i < marcianosArray.size(); i++) {
						marcianosArray.get(i).setVelocidad(5);
						marcianosArray.get(i).mover();

					}
				}
				repaint();
			}

		});

		this.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {

			}

			@Override
			public void keyReleased(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_LEFT) {
					estadoTeclas[0] = 0;
				}
				if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
					estadoTeclas[1] = 0;
				}
				if (estadoTeclas[0] == 0 && estadoTeclas[1] == 0) {
					nave.setVelocidad(0);
				}
				if (e.getKeyCode() == KeyEvent.VK_SPACE) {
					estadoTeclas[2] = 0;
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
				/*
				 * SIN CONTROLAR MULTITECLAS
				 * if(e.getKeyCode()==KeyEvent.VK_LEFT){
				 * 
				 * caballo.setVelocidad(-5); caballo.mover(); }
				 * if(e.getKeyCode()==KeyEvent.VK_RIGHT){
				 * caballo.setVelocidad(5); caballo.mover(); }
				 */

				// PARA CONTROLAR MULTITECLAS
				if (e.getKeyCode() == KeyEvent.VK_LEFT && estadoTeclas[1] == 0) {
					estadoTeclas[0] = 1;
				}
				if (e.getKeyCode() == KeyEvent.VK_RIGHT && estadoTeclas[0] == 0) {
					estadoTeclas[1] = 1;
				}
				if (e.getKeyCode() == KeyEvent.VK_SPACE) {
					if (nave.getEstado() == Nave.NORMAL) {
						// nave.setEstado(Nave.SUBIENDO);

					}
					estadoTeclas[2] = 1;
				}
				if (estadoTeclas[0] == 1) {
					nave.setVelocidad(-4);

				}
				if (estadoTeclas[1] == 1) {
					nave.setVelocidad(4);

				}
				if (estadoTeclas[2] == 1) {
					
				}
				repaint();
			}
		});
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(fondo, 0, 0, getWidth(), getHeight(), null);
		nave.dibujar(g);

		///////////////////////// MARCIANOS

		for (int i = 0; i < marcianosArray.size(); i++) {
			marcianosArray.get(i).dibujar(g);
			
		}

		///////////////////////// BALAS

		for (int i = 0; i < balasArray.size(); i++) {

			balasArray.get(i).dibujar(g);

		}

		requestFocus();
	}

	@Override
	public void update(Graphics g) {
		// CREAR EL BUFFER Y LA PANT VIRTUAL.
		// LLAMAR A paint CON LA VIRTUAL COMO PARAM
		buffer = createImage(getWidth(), getHeight());
		pantVirtual = buffer.getGraphics();
		paint(pantVirtual);
		g.drawImage(buffer, 0, 0, getWidth(), getHeight(), null);
		// VOLCAR LA IMAGEN ANTERIOR SOBRE GRAPHICS
	}

}
